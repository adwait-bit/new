﻿using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.DI
{
    public interface IUser
    {
        Task<string> Register(UserModel userModel);
        Task<string> UpdateUser(string emailid, UserModel userModel);
        Task<string> DeleteUser(string emailid);
    }
}
