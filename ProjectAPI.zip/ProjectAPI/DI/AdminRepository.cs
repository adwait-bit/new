﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using ProjectAPI.DataAccessLayer;
using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace ProjectAPI.DI
{
    public class AdminRepository : IAdmin
    {
        //public readonly pmsdbcontext dbcontext = null;
        //public ddminrepository(pmsdbcontext dbcontext)
        //{
        //    this.dbContext = dbContext;
        //}
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly IConfiguration configuration;



        public AdminRepository(UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager, IConfiguration configuration
            /*PMSDbContext pMSDbContext*/)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.configuration = configuration;
           
        }
        public async Task<IdentityResult> AdminModel(AdminModel adminModel)
        {
            var user = new ApplicationUser()
            {
                
                Email = adminModel.Email,
                UserName = adminModel.Email
            };
            return await userManager.CreateAsync(user, adminModel.Password);
        }
        public async Task<string> LoginAnync(AdminSignInModel adminSignInModel)
        {
            var result = await signInManager.PasswordSignInAsync(adminSignInModel.Email, adminSignInModel.Password, false, false);
            if (!result.Succeeded)
            {
                return null;
            }
            var authClaim = new List<Claim>
            {
                new Claim(ClaimTypes.Name,adminSignInModel.Email),
                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString())
            };
            var authsignkey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(configuration["JWT:Secret"]));
            var token = new JwtSecurityToken(
               issuer: configuration["JWT:ValidIssuer"],
                audience: configuration["JWT:ValidAudience"],
               expires: DateTime.Now.AddDays(1),
               claims: authClaim,
               signingCredentials: new SigningCredentials(authsignkey, SecurityAlgorithms.HmacSha256Signature)
               );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        //public  async Task<string> AdminLogin(AdminModel adminModel, string emailid, string password)
        //{

        //    var ar = await dbContext.adminModels.Where(x => x.Email == emailid && x.Password ==
        //      password).FirstOrDefaultAsync();
        //    return emailid;
        //}

        //public async Task<string> AdminRegister(AdminModel adminModel)
        //{
        //    dbContext.adminModels.Add(adminModel);
        //    await dbContext.SaveChangesAsync();
        //    return adminModel.Email;
        //}
        //public async Task<string> DeleteAdmin(string emailid)
        //{
        //    var ar = await dbContext.adminModels.Where(x => x.Email == emailid).FirstOrDefaultAsync();
        //    if (ar != null)
        //    {
        //        dbContext.adminModels.Remove(ar);
        //    }
        //    await dbContext.SaveChangesAsync();
        //    return emailid;
        //}

        //public async Task<int> DeletePolicy(int policyid)
        //{
        //    PolicyRegistrationModel ar = await dbContext.policyRegistrationModels.Where(
        //        x => x.PolicyId == policyid).FirstOrDefaultAsync();
        //    if(ar!=null)
        //    {
        //        dbContext.policyRegistrationModels.Remove(ar);
        //    }
        //    await dbContext.SaveChangesAsync();
        //    return policyid;
        //}

        //public async Task<string> UpdateAdmin(string emailid, AdminModel adminModel)
        //{
        //    var ar = await dbContext.adminModels.Where(x => x.Email == emailid).FirstOrDefaultAsync();
        //    if (ar != null)
        //    {
        //        ar.Password = adminModel.Password;
        //       // ar.ConfirmPass = adminModel.ConfirmPass;
        //    }
        //    await dbContext.SaveChangesAsync();
        //    return emailid;
        //}

        //public async Task<int> UpdatePolicy(int policyid, PolicyRegistrationModel policyRegistrationModel)
        //{
        //    var ar = await dbContext.policyRegistrationModels.Where(
        //       x => x.PolicyId == policyid).FirstOrDefaultAsync();
        //    if (ar != null)
        //    {
        //        ar.PolicyName = policyRegistrationModel.PolicyName;
        //        ar.StartDate = policyRegistrationModel.StartDate;
        //        ar.Duration = policyRegistrationModel.Duration;
        //        ar.CompanyName = policyRegistrationModel.CompanyName;
        //        ar.InitialDeposit = policyRegistrationModel.InitialDeposit;
        //        ar.PolicyType = policyRegistrationModel.PolicyType;
        //        ar.UserTypes = policyRegistrationModel.UserTypes;
        //        ar.Term = policyRegistrationModel.Term;
        //        ar.TermAmount = policyRegistrationModel.TermAmount;
        //        ar.Interest = policyRegistrationModel.Interest;
        //    }
        //    await dbContext.SaveChangesAsync();
        //    return policyid;
        //}

        //public Task UpdatePolicy(int policyid)
        //{
        //    throw new NotImplementedException();
        //}
    }
    
}
