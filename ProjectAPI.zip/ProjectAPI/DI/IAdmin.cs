﻿using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.DI
{
    public interface IAdmin
    {
        Task<string> AdminRegister(AdminModel adminModel);
        Task<string> DeleteAdmin(string emailid);
        Task<string> UpdateAdmin(string emailid, AdminModel adminModel);
    }
}
