﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectAPI.DI;
using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PolicyController : ControllerBase
    {
        private readonly IPolicy policy = null;
        public PolicyController(IPolicy policy)
        {
            this.policy = policy;
        }
        [HttpPost]
        public async Task<IActionResult> CreatePolicy([FromBody] PolicyRegistrationModel policymodel)
        {
            string a = await policy.RegisterPolicy(policymodel);
            return Ok(a);
        }
    }
}
