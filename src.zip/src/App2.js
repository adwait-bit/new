import React from 'react'
import DisplayLst from './DisplayLst';

export default function App2() {

const NameList=["Raj","Abhay","sumit"];
const EmpList=[
{Id:101,Name:"Raj",Salary:900000},
{Id:102,Name:"Rajee",Salary:2900000},
{Id:103,Name:"Raj kumar",Salary:1900000}

]

  return (
    <div>App2
<DisplayLst Name={NameList} EmployeeList={EmpList}></DisplayLst>


    </div>
  )
}
