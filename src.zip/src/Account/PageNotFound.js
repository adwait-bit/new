import React, { Component } from 'react'

export default class PageNotFound extends Component {
  render() {
    return (
      <div>The page you are looking for not found</div>
    )
  }
}
