import React, { Component } from 'react'
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';

export default class ShowProfile extends Component {
  render() {
    return (
      <div>ShowProfile
        <br></br>
        <Link to="/EditProfile">EditProfile</Link>
      </div>
    )
  }
}
