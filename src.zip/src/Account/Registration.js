import React, { Component } from 'react'

export default class Registration extends Component {
    constructor(props) {
      super(props)
    
      this.btnSubmit=this.btnSubmit.bind(this);
      this.inputusername=React.createRef();
      this.inputpassword=React.createRef();
    }
    btnSubmit()
    {
        alert("Username="+this.inputusername);
        alert("Password="+this.inputpassword);
        alert("Submit");
    }
  render() {
    return (
      <div className='App'>Registration
      
      <form onSubmit={this.btnSubmit}>
        <label>Username</label>
        <input type="text" ref={this.inputusername}></input><br></br>
        <label>Password</label>
        <input type="password" ref={this.inputpassword}></input><br></br>
        <button>Submit</button>
      </form>
      </div>

      
    )
  }
}
