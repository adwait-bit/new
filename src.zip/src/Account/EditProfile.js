import React, { Component } from 'react'

export default class EditProfile extends Component {
  render() {
    const UrlParam = new URLSearchParams(window.location.search);
    const userId = UrlParam.get('id');
    const Name = UrlParam.get('name');
    return (
      <div>EditProfile {userId} and {Name}</div>
    )
  }
}
