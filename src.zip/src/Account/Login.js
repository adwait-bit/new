import React, { Component } from 'react'

export default class Login extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         username:'',
         password:'',
         usernameerror:'',
         passworderror:''
      }
      this.btnSubmit=this.btnSubmit.bind(this);
    }

    btnSubmit()
    {
        this.setState({
            usernameerror:'',passworderror:''
        })
        if(this.Validate())
        {
        alert("done");
        // console.log(this);
        }
    }

Validate()
{
    if(!this.state.username.includes("@") && this.state.password.length<5)
    {
        this.setState({usernameerror:"Invalid Username",passworderror:"Password length should be more than 5 characters"})
    }
    else if(!this.state.username.includes("@"))
    {
        this.setState({usernameerror:"Invalid Username"})
    }
    else if(this.state.password.length<5)
    {
        this.setState({passworderror:"Password length should be more than 5 characters"})
    }
    else{
        return true;
    }
}
    render() {
    return (
      <div>Login <br></br>
        <label>Username</label>
        <input type="text" name="username"
         onChange={(e)=>this.setState({username:e.target.value})}></input><br></br>
        <p style={{color:"red"}}>{this.state.usernameerror}</p>
        <label>Password</label>
        <input type="password" name="password" 
        onChange={(e)=>this.setState({password:e.target.value})}></input><br></br>
        <p style={{color:"red"}}>{this.state.passworderror}</p>
        <button onClick={this.btnSubmit}>Submit</button>
      </div>
    )
  }
}
