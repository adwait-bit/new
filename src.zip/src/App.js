import logo from './logo.svg';
import './App.css';
import EventApp from './Eventex/EventApp';

function App() {
  return (
    <div className="App">
     <h1>This is my default Component</h1>
     <EventApp></EventApp>
    </div>
  );
}

export default App;
