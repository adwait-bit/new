import logo from './logo.svg';
import './App.css';
import AboutUs from './Services/AboutUs';
import Contact from './Services/Contact';
import Home from './Services/Home';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import Login from './Account/Login';
import Registration from './Account/Registration';
import ShowProfile from './Account/ShowProfile';
import EditProfile from './Account/EditProfile';
import PageNotFound from './Account/PageNotFound';
import Api from './ApiCall.js/Api';

function App() {
  return (
    <div className="App">
      <h1>This is app main component</h1>
<BrowserRouter>
<ul>
  <li><Link to="/">Home</Link></li>
  <li><Link to="/AboutUs">AboutUs</Link></li>
  <li><Link to="/Contact">Contact</Link></li>
  <li><Link to="/Login">Login</Link></li>
  <li><Link to="/Registration">Registration</Link></li>
  <li><Link to="/ShowProfile">ShowProfile</Link></li>
  <li><Link to="/Api">Show All Policy</Link></li>
  {/* <li><Link to="/EditProfile">EditProfile</Link></li> */}
</ul>
<Routes>
 <Route path='/' element={<Home/>}></Route>
 <Route path='/AboutUs' element={<AboutUs/>}></Route>
 <Route path='/Contact' element={<Contact/>}></Route>
 <Route path='/Login' element={<Login/>}></Route>
 <Route path='/Registration' element={<Registration/>}></Route>
 <Route path='/ShowProfile' element={<ShowProfile/>}></Route>
 <Route path='/EditProfile' element={<EditProfile/>}></Route>
 
 <Route path='/EditProfile/?id=id' element={<EditProfile/>}></Route>
 <Route path='/EditProfile/?id=id&Name=name' element={<EditProfile/>}></Route>
 <Route path='*' element={<PageNotFound/>}></Route>
 <Route path='/Api' element={<Api/>}></Route>
</Routes>
</BrowserRouter>

    </div>
  );
}

export default App;
