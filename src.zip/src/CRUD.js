import React, { Component } from 'react'
import './App.css';

export default class CRUD extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         Policy:[],
         PolicyId:'',
         PolicyName:'',
         duration:''
      }
      this.create=this.create.bind(this);
      this.update=this.update.bind(this);
      this.delete=this.delete.bind(this);
    }
    DisplayPolicies()
    {
        let url="http://localhost:50450/api/policy";
        fetch(url).then(response=>response.json().then(result=>{
            this.setState({Policy:result})
        }));
    }
    componentDidMount()
    {
        this.DisplayPolicies();
    }
    componentDidUpdate()
    {
        this.DisplayPolicies();
    }
    handleChange(changeObject)
    {
        this.setState(changeObject);
    }
    create()
    {
        let url = "http://localhost:50450/api/policy";
        fetch(url,
            {
                "method":"POST",
                "headers":{
                    "content-type":"application/json",
                    "accept":"application/json"
                },
                body:JSON.stringify({
                    name:this.state.PolicyName,
                    duration:this.state.duration
                })
            }).then(response=>response.json()).then(response=>{
                alert("Data Inserted");
            }).catch(err=>{
                console.warn(err);
            })
    }  
    update()
    {
       let id = this.state.PolicyId;
       let url = "http://localhost:50450/api/policy"+id;
        fetch(url,
            {
                "method":"PUT",
                "headers":{
                    "content-type":"application/json",
                    "accept":"application/json"
                },
                body:JSON.stringify({
                    name:this.state.PolicyName,
                    duration:this.state.duration
                })
            }).then(response=>response.json()).then(response=>{
                alert("Data Updated");
            }).catch(err=>{
                console.warn(err);
            }) 
    }  
    delete()
    {
        let id = this.state.PolicyId;
        let url = "http://localhost:50450/api/policy"+id;
         fetch(url,
             {
                 "method":"DELETE",
                 "headers":{
                     "content-type":"application/json",
                     "accept":"application/json"
                 },
                 body:JSON.stringify({
                     name:this.state.PolicyName,
                     duration:this.state.duration
                 })
             }).then(response=>response.json()).then(response=>{
                 alert("Data Deleted");
             }).catch(err=>{
                 console.warn(err);
             })    
    }
  render() {
    const {Policy} = this.state;
    return (
      <><div className='App'>CRUD</div>
      <table>
      <tr>
            <td>
                <label>Policy Id</label>
                <input type="text" name="id" onChange={(e)=>this.handleChange({PolicyId:e.target.value})}></input>
            
            </td>
        </tr>
        <tr>
            <td>
                <label>Policy Name</label>
                <input type="text" name="PolicyName" onChange={(e)=>this.handleChange({PolicyName:e.target.value})}></input>
            
            </td>
        </tr>
        <tr>
            <td>
                <label>Policy Duration</label>
                <input type="text" name="duration" onChange={(e)=>this.handleChange({duration:e.target.value})}></input>
            
            </td>
        </tr>
        <tr>
            <td>
                <button onClick={this.create}>Create</button>
                <button onClick={this.update}>Update</button>
                <button onClick={this.delete}>Delete</button>
            
            </td>
        </tr>
        </table>
        <table>
<tr>
    <td>Policy Id</td>
    <td>Policy Name</td>
    <td>Policy Duration</td>
</tr>
{
    Policy.map(a=>
    <tr>
        <td>{a.PolicyId}</td>
        <td>{a.PolicyName}</td>
        <td>{a.duration}</td>
    </tr>)
}

        </table>
        </>
    )
  }
}

