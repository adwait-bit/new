import React from 'react'

export default function NameList(props) {

    const myLists=props.myLists;

const listitem=myLists.map((a,index1)=>
{
    <li key={index1}>{a}</li>
}
    // <li>{a}</li>
);
// const updatedLists = stringLists.map((strList, index)=>{
//     <li key={index}> {strList} </li>;
//     });



const myLists1=props.data;
const empinfo=myLists1.map((item=>
    <div>
        <li>{item.Id}</li>
    </div>
    ))

// const num=props.Numbers;
// const n=num.map((a1=>
//     <li>{a1}</li>
//     ))

  return (

    <div>NameList

        <ul>{listitem}</ul>
        {/* <ul>{n}</ul> */}

        <ul>{empinfo}</ul>
    </div>
  )
}
