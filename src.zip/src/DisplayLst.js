import React from 'react'
import './App.css';

export default function DisplayLst(props) {

const namelist=props.Name;

const arname=namelist.map((item=>
    <li>{item}</li>
    ))

const emplist=props.EmployeeList;
const rs=emplist.map((ar=>
    <tr>
        <td>{ar.Id}</td>
        <td>{ar.Name}</td>
        <td>{ar.Salary}</td>
    </tr>
    ))



  return (
    <><div>DisplayLst

          <ul>{arname}</ul>


      </div><div className='App'>
        <table border={1} cellPadding="2">
            <tr>
                <th>Employee Id</th>
                <th>Employee Name</th>
                <th>Employee Salary</th>
            </tr>
            {rs}
        </table>
        
        </div></>
  )
}
