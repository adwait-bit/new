import React, { Component } from 'react'

export default class Api extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         Policy:[]
      }
    }
    refreshList()
    {
        let url = "http://localhost:50450/api/policy";
        fetch(url).then(response=>response.json().then(result=>{
            this.setState({Policy:result});
        }))
    }
    componentDidMount()
    {
       this.refreshList(); 
    }
  render() {
    const {Policy}=this.state;
    return (
      <div>ShowAllPolicy
        <table>
          <tr>
            <td>Policy Id</td>
            <td>Policy Name</td>
            <td>Policy Duration</td>
          </tr>
          {
            Policy.map(a=>
              <tr>
                <td>{a.PolicyId}</td>
                <td>{a.name}</td>
                <td>{a.duration}</td>
              </tr>
              )
          }
        </table>
      </div>
    )
  }
}
