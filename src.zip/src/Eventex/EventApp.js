import React, { Component } from 'react'

export default class EventApp extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         message:'Hello How r u'
      }
    }
    ClickHandler()
    {
        this.setState({
            message:"GoodBye!!"
        })
        console.log(this);
    }
  
  render() {
    return (
      <div>{this.state.message}
       <button onClick={this.ClickHandler} >Submit</button>
      <button onClick={this.ClickHandler.bind(this)} >Submit1</button>
      <button onClick={()=>this.ClickHandler()} >Submit2</button>
      </div>

    )
  }
}
