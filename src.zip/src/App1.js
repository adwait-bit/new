import React from 'react'
import NameList from './NameList';

export default function App1() {

const myLists=['A','B','C','D'];
const nums=[11,22,33,44,55];
const data=[
    {Id:101,Name:"Raj",Salary:90000},
    {Id:102,Name:"Rajee",Salary:290000},
    {Id:103,Name:"Raj kumar",Salary:190000}
]



  return (
    <div>App1
{
//  <><NameList Name={myLists}></NameList><NameList Name={nums}></NameList>
 <NameList myLists={myLists}  nums={nums} data={data}></NameList>


  }


    </div>
  )
}
