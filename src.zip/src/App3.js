import React, { Component } from 'react'

export default class App3 extends Component {
constructor(props) {
  super(props)

  this.state = {
     Employee:[
        {EmpId:101,EmpName:'Raj',Salary:90000},
        {EmpId:102,EmpName:'Rajee',Salary:90000},
        {EmpId:103,EmpName:'Kumar',Salary:190000}
     ]
  }
}

  render() {

    let ar=this.state.Employee.map(item=>
        <tr>
            <td>{item.EmpId}</td>
            <td>{item.EmpName}</td>
            <td>{item.Salary}</td>
        </tr>
        )
    return (
      <div>App3

<table>
    <tr>
        <td>EmpId</td>
        <td>EmpName</td>
        <td>EmpSalary</td>
    </tr>
    {
        this.state.Employee.map((item,index)=>
            <tr>
                {/* <td>{index+1}</td> */}
                <td>{index+1}</td>
                <td>{item.EmpId}</td>
                <td>{item.EmpName}</td>
                <td>{item.Salary}</td>
            </tr>
            )
    }
</table>
<table border={2}>
    <tr>
        <td>EmpId</td>
        <td>EmpName</td>
        <td>EmpSalary</td>
    </tr>
    {
    ar
    }
</table>

      </div>
    )
  }
}
